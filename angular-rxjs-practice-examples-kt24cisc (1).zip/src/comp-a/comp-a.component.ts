import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { SharedService } from '../services/shared.service';
import { UserForm } from '../interface/use-form';

@Component({
  selector: 'app-comp-a',
  templateUrl: './comp-a.component.html',
  styleUrls: ['./comp-a.component.css']
})
export class CompAComponent implements OnInit {
  form: FormGroup;
  username: string = '';
  private subscription = new Subscription();

  constructor(private sharedService:SharedService, private router: Router,   private fb: FormBuilder) {}

  ngOnInit() {
    this.form = this.fb.group({
      username: [''],
      email: [''],
      password: [''],
      role: ['Guest'],
      termsAccepted: [false]
    });

    const sub = this.sharedService.form$.subscribe(data => {
      this.form.patchValue(data);
    });
    this.subscription.add(sub);
  }


  onInputChange(field: keyof UserForm, value: string) {
    this.sharedService.updateFormField(field, value);
  }


  updateName(name: string) {
    this.sharedService.setUsername(name); // Update service value immediately
  }

  saveDraft() {
    this.sharedService.saveDraft();
  }

  loadDraft() {
    this.sharedService.loadDraft();
  }
  
  goToComponentB() {
    this.router.navigate(['/component-b']);
  }

  goBacktoDashboard() {
    this.sharedService.resetForm();
    this.router.navigate(['']);
  }

  submit(){
    console.log(this.form.value)
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    console.log("destry")
    // Optional: reset state here if you want
    //  this.sharedService.resetUsername();
  }
}