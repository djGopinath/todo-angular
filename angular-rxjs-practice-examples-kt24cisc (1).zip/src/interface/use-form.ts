export interface UserForm {
  firstname: string;
  lastname: string;
  email: string;
  role: 'Admin' | 'Guest';   
  termsAccepted: boolean;
}
