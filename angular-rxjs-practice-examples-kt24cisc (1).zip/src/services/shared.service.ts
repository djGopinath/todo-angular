import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { UserForm } from './use-form';

@Injectable({ providedIn: 'root' })
export class SharedService {
  private usernameSubject = new BehaviorSubject<string>('');
  private formSubject = new BehaviorSubject<UserForm>({
    firstname: '',
    email: '',
    lastname: '',
    role: 'Admin',          // default role
    termsAccepted: false,   // default unchecked
  });
  
  username$ = this.usernameSubject.asObservable();
  form$: Observable<UserForm> = this.formSubject.asObservable();
  private draft: UserForm | null = null;
  constructor() { }

  setUsername(newName: string) {
    this.usernameSubject.next(newName);
  }

  resetUsername() {
    this.usernameSubject.next('');
  }

  updateFormField(field: keyof UserForm, value: string) {
    const currentForm = this.formSubject.value;
    this.formSubject.next({ ...currentForm, [field]: value });
  }

  updateWholeForm(form: UserForm) {
    this.formSubject.next(form);
  }

  saveDraft() {
    this.draft = this.formSubject.value;  // Save current form as draft
    localStorage.setItem('userFormDraft', JSON.stringify(this.draft));
    console.log('Draft saved:', this.draft);
  }

  loadDraft() {
    const savedDraft = localStorage.getItem('userFormDraft');
    if (savedDraft) {
      this.draft = JSON.parse(savedDraft);
      this.formSubject.next(this.draft);
    }
  }

  resetForm() {
    this.formSubject.next({ 
    firstname: '',
    email: '',
    lastname: '',
    role: 'Admin',          // default role
    termsAccepted: false,    });
  }
}