import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { CompAComponent } from '../comp-a/comp-a.component';
import { CompBComponent } from '../comp-b/comp-b.component';
import { AppRoutingModule } from './app-routing.module';
import { LandingPageComponent } from '../landing-page/landing-page.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports:      [ BrowserModule, FormsModule,AppRoutingModule,ReactiveFormsModule ],
  declarations: [ AppComponent, CompAComponent, CompBComponent,LandingPageComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
