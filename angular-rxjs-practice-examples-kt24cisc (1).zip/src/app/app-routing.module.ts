import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { CompAComponent } from '../comp-a/comp-a.component';
import { CompBComponent } from '../comp-b/comp-b.component';
import { LandingPageComponent } from '../landing-page/landing-page.component';
const routes: Routes = [
  { path: '', component: LandingPageComponent }, // root route
  { path: 'component-a', component: CompAComponent },
  { path: 'component-b', component: CompBComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }