import { Component, OnDestroy } from '@angular/core';
import { mapTo, takeUntil, take, combineLatest, combineAll, shareReplay } from 'rxjs/operators';
import { interval, merge, Subject, ReplaySubject, of, timer, BehaviorSubject } from 'rxjs';
import { OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  constructor(private router: Router) {}

  goToComponentA() {
    this.router.navigate(['/component-a']);
  }

 
}
